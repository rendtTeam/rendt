print('code2 successfully executed as well!')
