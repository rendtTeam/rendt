echo "script 1"

python exec_test.py

echo "next"

python exec_test2.py

echo "the end"
